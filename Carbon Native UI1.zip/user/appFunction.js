function checkIt() {
  alert("You clicked Check!");
}