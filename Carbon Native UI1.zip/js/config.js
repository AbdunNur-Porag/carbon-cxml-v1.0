// this file use for initial launch
render("../view/app.js", "app");
/*
setTimeout(()=>{
  render("../view/app.js","app")
},1500)*/